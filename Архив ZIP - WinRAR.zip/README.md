# Bloody Netlify Panel

Панель для ключей/HWID на Netlify.

## Пароль

```text
liberlyxx8
```

Можно поменять через переменную окружения Netlify:

```text
BLOODY_ADMIN_PASSWORD
```

## Стартовые ключи

```text
482915703641
730284916552
196407582330
845230719684
309571846205
```

## Публикация

Загрузи всю папку `netlify-site` на Netlify.

После публикации API будет:

```text
https://YOUR-SITE.netlify.app/api
```

Jar нужно будет пересобрать под этот адрес.
